<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    .titulo{
      text-align: center;
      color: blue;
    }
    table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
      width: 100%;
    }
    #container{
      background-color: rgb(251, 245, 245);
      width: 200px;
      height: 90px;
      margin-left:auto; margin-right:0;
    }
  </style>
</head>
<body>
<center>
  <h2>Reporte de la venta</h2>
  <hr>
  <h4><p>Numero de Pedido:</p>6576576</h4>
  <h4><strong><p>Cliente:</p></strong> <?php echo e(session('session_name')); ?> <?php echo e(session('session_app')); ?> </h4>
  <h4></h4>
  <br>
  <?php $valor=0 ?>
    <table style="border: 1px solid black;
    border-collapse: collapse;">
		<thead>
			<tr>
				<th>No. </th>
				<th>cantidad</th>
				<th>nombre</th>
				<th>Precio</th>
        <th>Total</th>
			</tr>
		</thead>
		<?php $__currentLoopData = Cart::getContent(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $valor += $item['price'] * $item['quantity']?>
      <tbody>
        <tr>
          <td><?php echo e($item->id); ?></td>
          <td><?php echo e($item->quantity); ?></td>
          <td><?php echo e($item->name); ?></td>
          <td>$ <?php echo e($item->price); ?></td>
          <td>$ <?php echo e($item->price * $item->quantity); ?></td>
        </tr>
      </tbody>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <div id="container">
      <table>
        <tr>
              <td><strong> Subtotal:</strong>  $<?php echo e($valor); ?> </td>
        </tr>
        <tr>
              <td><strong>IVA: </strong>  16%</td>
        </tr>
        <tr>
              <td><dt><strong>Total:</strong> $<?php echo e($valor+$valor*0.16); ?></dt></td>
        </tr>
      </table>
  </div>
    <hr> 
    <br>
    <br>
    <br>
    <h5>¡¡¡ Gracias por su preferencia !!!</h5>
    <label>Para mas informacion puede diregirse a nuestro correo electronico de <a href="https://mail.google.com/mail/u/0/#inbox">fabricadelavaderos.eltigre@gmail.com</a></label> 
    </center>

</body>
</html><?php /**PATH C:\Users\al221\Lavaderos_elTigre\resources\views/Detalle-pedido.blade.php ENDPATH**/ ?>