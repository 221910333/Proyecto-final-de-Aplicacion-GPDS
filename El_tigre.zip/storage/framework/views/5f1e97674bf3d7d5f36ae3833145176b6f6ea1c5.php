<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=}, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mesaje recibido</title>
</head>
<body>
    <img src="<?php echo e(asset('images/tiger.png')); ?>" alt="El tigre">
    <p><strong>Recibiste un mensaje de:</strong> <?php echo e($msg['Nombre']); ?></p>
    <p><strong>Correo Electronico:</strong> <?php echo e($msg['Correo']); ?></p>
    <p><strong>Asunto:</strong> <?php echo e($msg['Sujeto']); ?></p>
    <p><strong>Mensaje:</strong> <?php echo e($msg['Mensaje']); ?></p>

</body>
</html>
<?php /**PATH C:\Users\al221\Lavaderos_elTigre\resources\views/correo.blade.php ENDPATH**/ ?>