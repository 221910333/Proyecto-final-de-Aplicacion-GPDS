<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Fabrica_De_Lavaderos "El Tigre" '): ?>
<img src="assets/img/ti.png" class="logo" alt="El tigre Logo">
<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\Users\al221\Lavaderos_elTigre\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>