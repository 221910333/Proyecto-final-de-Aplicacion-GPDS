<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <title>Bienvenido a mi Formulario</title>
</head>

<body>
    <center>
    <div class="container-form sign-up">
        <div class="welcome-back">
        </div>
        <form class="formulario" id="form" action="<?php echo e(route('guarduarusuario')); ?>" method="POST" role="form">
                    <?php echo e(csrf_field()); ?>

                    <br>
            <h1>Registrar un usuario</h1>
            <br>
            <hr><hr><hr><hr><hr><hr>
            <br>
            <br><br>
            <div class="formulario__grupo" id="grupo__nombre">
                <label for="nombre" class="formulario__label">nombre</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control" >
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El Nombre debe ser de 4 a 20 digitos <strong>Letras</strong></p>
            </div>
            <div class="formulario__grupo" id="grupo__app">
                <label for="app" class="formulario__label">Apellido Peterno</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="app" id="app" value="<?php echo e(old('app')); ?>" class="form-control" >
                    <?php $__errorArgs = ['app'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El Apellido paterno debe ser de 4 a 16 digitos <strong>Letras</strong></p>
            </div>
            <div class="formulario__grupo" id="grupo__apm">
                <label for="apm" class="formulario__label">Apellido Materno</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="apm" id="apm" value="<?php echo e(old('apm')); ?>" class="form-control">
                    <?php $__errorArgs = ['apm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El apellido materno debe ser de 4 a 16 digitos <strong>Letras</strong></p>
            </div>
            <div class="formulario__grupo" id="grupo__fecha">
                <label for="fecha" class="formulario__label">Fecha Nacimiento</label>
                <div class="formulario__grupo-input">
                    <input type="date" class="formulario__input" name="fecha" id="fecha" value="<?php echo e(old('fecha')); ?>" class="form-control">
                    <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">Debe seleccionar su fecha de nacimiento</p>
            </div>
            <div class="formulario__grupo" id="grupo__direccion">
                <label for="direccion" class="formulario__label">Direccion</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="direccion" id="direccion" value="<?php echo e(old('direccion')); ?>" class="form-control">
                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">La direccion debe ser de 4 a 50 digitos</p>
            </div>
            <div class="formulario__grupo" id="grupo__telefono1">
                <label for="telefono1" class="formulario__label">Telefono 1</label>
                <div class="formulario__grupo-input">
                    <input type="number" class="formulario__input" name="telefono1" id="telefono1" value="<?php echo e(old('telefono1')); ?>" class="form-control">
                    <?php $__errorArgs = ['telefono1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El Telefono debe ser de 10 numeros</p>
            </div>
            <div class="formulario__grupo" id="grupo__telefono2">
                <label for="telefono2" class="formulario__label">Telefono 2</label>
                <div class="formulario__grupo-input">
                    <input type="number" class="formulario__input" name="telefono2" id="telefono2" value="<?php echo e(old('telefono2')); ?>" class="form-control">
                    <?php $__errorArgs = ['telefono2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El Telefono debe ser de 10 numeros</p>
            </div>
            <div class="formulario__grupo" id="grupo__email">
                <label for="email" class="formulario__label">Correo</label>
                <div class="formulario__grupo-input">
                    <input type="email" class="formulario__input" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El Correo debe llevar un @ y ser de tipo email</p>
            </div>
            <div class="formulario__grupo" id="grupo__pass">
                <label for="pass" class="formulario__label">Contraseña</label>
                <div class="formulario__grupo-input">
                    <input type="password" class="formulario__input" name="pass" id="pass" value="<?php echo e(old('pass')); ?>" class="form-control">
                    <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">La contraseña debe ser de 8 a 16 digitos</p>
            </div><br><br>
            Seleccione el Tipo de usuario
            <br><br>
            <div class="formulario__grupo" id="grupo__tipousuario">
              <select name="id_tipousuario" id="">
                <?php $__currentLoopData = $tipousuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option class="formulario__btn" value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
                <?php $__errorArgs = ['id_tipousuario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="error-message"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <br><br>
            <button type="submit" class="formulario__btn" value="registrar">Registrar</button>

        </form>
    </div>
    </center>
    <script src="script.js"></script>
    <script src="<?php echo e(asset('js/form.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/u487073322/domains/fabricadelavaderoseltigre.net/public_html/el_tigre/resources/views/agregar/agregarusuario.blade.php ENDPATH**/ ?>