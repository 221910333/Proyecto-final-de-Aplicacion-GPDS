<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\al221\Lavaderos_elTigre\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>