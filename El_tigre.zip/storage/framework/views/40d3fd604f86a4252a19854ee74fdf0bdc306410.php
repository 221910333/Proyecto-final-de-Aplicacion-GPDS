<!DOCTYPE html>
<html lang="en">
css
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    <title>Bienvenido a mi Formulario</title>
</head>

<body>
    <center>
    <div class="container-form sign-up">
        <div class="welcome-back">
        </div>
        <form class="formulario" id="form" action="<?php echo e(route('salvar1',['id'=> $usu->id])); ?>" method="POST" role="form">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

                    <br>
                    <h1>Editar un usuario</h1>
                    <br>
                    <hr><hr><hr><hr><hr><hr>
                    <br>
                    <br><br>
                    <div class="formulario__grupo" id="grupo__nombre">
                        <label for="nombre" class="formulario__label">nombre</label>
                        <div class="formulario__grupo-input">
                            <input type="text" class="formulario__input" name="nombre" id="nombre" value="<?php echo e($usu->nombre); ?>" class="form-control" required placeholder="Nombre">
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">El Nombre debe ser de 4 a 20 digitos <strong>Letras</strong></p>
                    </div>
                    <div class="formulario__grupo" id="grupo__app">
                        <label for="app" class="formulario__label">Apellido Peterno</label>
                        <div class="formulario__grupo-input">
                            <input type="text" class="formulario__input" name="app" id="app" value="<?php echo e($usu->app); ?>" class="form-control" required placeholder="Apellido Paterno">
                            <?php $__errorArgs = ['app'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">El Apellido paterno debe ser de 4 a 16 digitos <strong>Letras</strong></p>
                    </div>
                    <div class="formulario__grupo" id="grupo__apm">
                        <label for="apm" class="formulario__label">Apellido Materno</label>
                        <div class="formulario__grupo-input">
                            <input type="text" class="formulario__input" name=" apm" id="apm" value="<?php echo e($usu->apm); ?>" class="form-control" required placeholder="Apellido Materno">
                            <?php $__errorArgs = ['apm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">El apellido materno debe ser de 4 a 16 digitos <strong>Letras</strong></p>
                    </div>
                    <div class="formulario__grupo" id="grupo__fecha">
                        <label for="fecha" class="formulario__label">Fecha Nacimiento</label>
                        <div class="formulario__grupo-input">
                            <input type="date" class="formulario__input" name=" fecha" id="fecha" value="<?php echo e($usu->fecha); ?>" class="form-control" required placeholder="Fecha de Nacimiento">
                            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">Debe seleccionar su fecha de nacimiento</p>
                    </div>
                    <div class="formulario__grupo" id="grupo__direccion">
                        <label for="direccion" class="formulario__label">Direccion</label>
                        <div class="formulario__grupo-input">
                            <input type="text" class="formulario__input" name="direccion" id="direccion" value="<?php echo e($usu->direccion); ?>" class="form-control" required placeholder="Direccion">
                            <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">La direccion debe ser de 4 a 50 digitos</p>
                    </div>
                    <div class="formulario__grupo" id="grupo__telefono1">
                        <label for="telefono1" class="formulario__label">Telefono 1</label>
                        <div class="formulario__grupo-input">
                            <input type="number" class="formulario__input" name=" telefono1" id="telefono1" value="<?php echo e($usu->telefono1); ?>" class="form-control" required placeholder="Telefono1">
                            <?php $__errorArgs = ['telefono1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">El Telefono debe ser de 10 numeros</p>
                    </div>
                    <div class="formulario__grupo" id="grupo__telefono2">
                        <label for="telefono2" class="formulario__label">Telefono 2</label>
                        <div class="formulario__grupo-input">
                            <input type="number" class="formulario__input" name="telefono2" id="telefono2" value="<?php echo e($usu->telefono2); ?>" class="form-control" required placeholder="Telefono2">
                            <?php $__errorArgs = ['telefono2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">El Telefono debe ser de 10 numeros</p>
                    </div>
                    <div class="formulario__grupo" id="grupo__email">
                        <label for="email" class="formulario__label">Correo</label>
                        <div class="formulario__grupo-input">
                            <input type="email" class="formulario__input" name="email" id="email" value="<?php echo e($usu->email); ?>" class="form-control" required placeholder="Email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">El Correo debe llevar un @ y ser de tipo email</p>
                    </div>
                    <div class="formulario__grupo" id="grupo__pass">
                        <label for="pass" class="formulario__label">Contraseña</label>
                        <div class="formulario__grupo-input">
                            <input type="password" class="formulario__input" name="pass" value="<?php echo e($usu->pass); ?>" class="form-control" required placeholder="Password">
                            <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="error-message"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <i class="formulario__validacion-estado fas fa-times-circle"></i>
                        </div>
                        <p class="formulario__input-error">La contraseña debe ser de 8 a 16 digitos</p>
                    </div><br><br>
                    Seleccione el Tipo de usuario
                    <br><br>
              <select name="id_tipousuario" id="">
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($usu->id_tipousuario == $tipo->id): ?>
                <option class="formulario__btn" value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($usu->id_tipousuario != $tipo->id): ?>
                    <option class="formulario__btn" value="<?php echo e($tipo->id); ?>"><?php echo e($tipo->nombre); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>

            <br><br>
            <button type="submit"  class="formulario__btn" value="Salvar">Salvar</button>
        </form>
    </div>
    </center>
    <script src="script.js"></script>
    <script src="js/form-usuarios.js"></script>
</body>

</html>
<?php /**PATH C:\Users\al221\Lavaderos_elTigre\resources\views/editar/editarusuario.blade.php ENDPATH**/ ?>