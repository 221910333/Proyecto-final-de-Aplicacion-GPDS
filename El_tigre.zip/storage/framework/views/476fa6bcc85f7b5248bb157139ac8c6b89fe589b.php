<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\al221\Lavaderos_elTigre\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>