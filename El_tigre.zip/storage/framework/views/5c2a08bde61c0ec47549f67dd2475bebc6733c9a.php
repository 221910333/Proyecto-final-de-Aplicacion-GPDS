<?php echo e($slot); ?>

<?php /**PATH C:\Users\al221\Lavaderos_elTigre\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>