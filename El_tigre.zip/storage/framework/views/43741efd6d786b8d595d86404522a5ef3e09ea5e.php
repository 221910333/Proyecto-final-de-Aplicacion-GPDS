<?php echo e($slot); ?>

<?php /**PATH C:\Users\al221\Lavaderos_elTigre\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>